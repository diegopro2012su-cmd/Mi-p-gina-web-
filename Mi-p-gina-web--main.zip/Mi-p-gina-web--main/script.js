function saludo() {
    alert("¡Hola! Esto funciona gracias a GitHub Pages 😄");
}